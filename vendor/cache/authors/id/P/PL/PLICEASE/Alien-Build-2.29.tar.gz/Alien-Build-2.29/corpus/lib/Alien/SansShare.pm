package Alien::SansShare;

use strict;
use warnings;
use base qw( Alien::Base );

1;
