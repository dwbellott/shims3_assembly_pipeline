#!/bin/sh
env PERL_HASH_SEED= PERL_HASH_SEED_DEBUG=1 make test
