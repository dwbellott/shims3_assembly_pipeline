package MyGraph;

use Graph;
use base 'Graph';

1;
